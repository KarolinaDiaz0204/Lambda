﻿using System;


namespace Lambda
{
    class Estudiante
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }
        public double Nota { get; set; }
    }
}

